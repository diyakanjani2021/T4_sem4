const expr=require('express')
const mg=require('mongoose')
const cors=require('cors')
const app=expr()
app.use(cors())
app.use(expr.json())

mg.connect('mongodb://127.0.0.1:27017/Rdata').then(()=>{console.log('success')}).catch((err)=>{console.error(err)})

const userschema=new mg.Schema({username:String})
const user=new mg.model('user',userschema)
app.post('/signup',async(req,res)=>{
    try{
        const newuser=new user({username:req.body.username})
        await newuser.save()
        res.send()
    }
    catch(err){
        res.send(err)
    }
})
app.listen(5000)