import logo from './logo.svg';
import './App.css';
import Signup from './Signup'

function App() {
  return (
   <Signup/>
  );
}

export default App;
