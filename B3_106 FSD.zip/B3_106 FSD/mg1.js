const mg=require('mongoose')
mg.connect("mongodb://127.0.0.1:27017/connect").then(()=>console.log('success')).catch((err)=>console.error(err))  //connect is the db name
const myschema=new mg.Schema({name:String,age:Number,email:{type:String,required:true},date:{type:Date,default:new Date()}})
//mg.pluralize(null)  if this is not written then collection name will be people
const person=new mg.model('person',myschema) //person is collection name
const pdata=new person({name:'jay',age:28,email:'jay@gmail.com'})
pdata.save()