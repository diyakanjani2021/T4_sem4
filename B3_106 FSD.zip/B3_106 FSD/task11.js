const v=require('validator')
const mg=require('mongoose')
mg.connect("mongodb://127.0.0.1:27017/b3_6").then(()=>console.log('success')).catch((err)=>console.error(err))
myschema=new mg.Schema({
    email:{type:String,required:true,unique:true,validate:[v.isEmail,'This is not valid email']},
    product:{type:String,required:true,validate:[v.isAlphaNumeric,'This is not a valid alphanumeric code']}
})
const data=new mg.model('user',myschema)
const createDoc=async()=>{
    try {
        const pdata=new data({email:'r@gmail.com',product:'mobile'})
        pdata.save()
    } catch (error) {
        console.log(error)
    }
}
createDoc()