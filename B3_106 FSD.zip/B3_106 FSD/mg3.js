const mg=require('mongoose')
mg.connect("mongodb://127.0.0.1:27017/b3_5").then(()=>console.log('success')).catch((err)=>console.error(err))
const myschema=new mg.Schema({name:String,age:Number,status:Boolean})
const data=new mg.model('person',myschema)
const createdata=async()=>{
    try {
        const pdata=new data({name:'Raj',age:22})
        const pdata1=new data({name:'Jay',age:33})
        const result=await data.insertMany([pdata,pdata1])
        const result1=await data.find()
        console.log(result1)
        const result2=await data.find({name:'abc',_id:0})
        console.log(result2)
    } catch (error) {
        console.log(error)
    }
}
createdata()