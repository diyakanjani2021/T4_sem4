import {useState} from 'react'
import axios from 'axios'
function Signup(){
    const [username,setusername]=useState('')
    const hs=async(e)=>{
        e.preventDefault()
        try {
            await axios.post('http://localhost:5000/signup',{username})
            alert('signup done')
            setusername('')
        } catch (error) {
            alert('error occured')
        }
    }
    return(
        <>
        <form onSubmit={hs} method='post'>
            User:<input type='text' onchange={(e)=>setusername(e.target.value)}/>
            <button type='submit'>Register</button>
        </form>
        </>
    )
}
export default Signup