const v=require('validator')
const mg=require('mongoose')
mg.connect("mongodb://127.0.0.1:27017/b3_6").then(()=>console.log('success')).catch((err)=>console.error(err))
myschema=new mg.Schema({
    username:{type:String,required:true,minlength:[4,'minimum 4 letters required'],maxlength:20,trim:true,uppercase:true},
    email:{type:String,required:true,unique:true,validate:[v.isEmail,'This is not valid email']},
    age:{type:Number,required:true,min:18,max:65},
    role:{type:String,enum:['admin','user'],default:'user',lowercase:true}
})
mg.pluralize(null)
const data=mg.model('person',myschema)
pdata=new data({username:'rohan',email:'r@gmail.com',age:34,role:'admin'})
pdata.save()