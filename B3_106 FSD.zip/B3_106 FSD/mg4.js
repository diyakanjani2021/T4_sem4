//task
const mg=require('mongoose')
mg.connect("mongodb://127.0.0.1:27017/b3_5").then(()=>console.log('success')).catch((err)=>console.error(err))
const myschema=new mg.Schema({name:String,surname:String,age:Number,active:Boolean})
const data=new mg.model('task1',myschema)
const createdata=async()=>{
    try {
        finaldata=[{name:'test',surname:'test1',age:33,active:true},{name:'hi',surname:'hi1',age:30,active:true},{name:'hello',surname:'hello1',age:28,active:true},{name:'hello',surname:'hello11',age:10,active:true},{name:'abc',surname:'xyz',age:106,active:false}]
        const result=[]
        result.push(await data.insertMany(finaldata))
        result.push(await data.find({name:'hello'},{_id:0}))
        result.push(await data.find({age:{$gt:30}},{name:1,active:1,_id:0}))
        result.push(await data.find({surname:'xyz'},{active:1,_id:0}))
        result.push(await data.updateMany({age:10},{$set:{age:20}}))
        console.log(result)
    } catch (error) {
        console.log(error)
    }
}
createdata()
//.updateOne(filter,update,option,CB)   filter={key:value}
//.findByIdAndUpdate(id,update,option,CB)
//.findByIdAndDelete(id)